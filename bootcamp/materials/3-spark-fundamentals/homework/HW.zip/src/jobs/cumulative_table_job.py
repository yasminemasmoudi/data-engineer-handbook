from pyspark.sql import functions as F

def transform_cumulative_table(spark_session, input_df):
    """
    Aggregates actor data to produce a cumulative summary table.
    """
    result_df = (
        input_df.groupBy("actorid", "actor")
        .agg(
            F.collect_list("film").alias("films"),
            F.avg("rating").alias("avg_recent_rating"),
            F.max("year").alias("current_year")
        )
    )
    return result_df
