from pyspark.sql import functions as F
from pyspark.sql.window import Window

def transform_actors_history_scd(spark_session, input_df):
    """
    Transforms actors' history into a slowly changing dimension format.
    """
    window_spec = Window.partitionBy("actorid").orderBy("current_year")
    
    result_df = (
        input_df
        .withColumn("prev_is_active", F.lag("is_active").over(window_spec))
        .withColumn("is_changed", F.when(F.col("is_active") != F.col("prev_is_active"), 1).otherwise(0))
        .withColumn("change_streak", F.sum("is_changed").over(window_spec))
        .withColumn("start_date", F.col("current_year"))
        .withColumn("end_date", F.lead("current_year").over(window_spec))
        .withColumn("current_flag", F.when(F.col("end_date").isNull(), True).otherwise(False))
    )
    
    result_df = result_df.select(
        "actor", "actorid", "start_date", "end_date", "quality_class",
        "is_active", "current_flag", "change_streak"
    )
    return result_df
