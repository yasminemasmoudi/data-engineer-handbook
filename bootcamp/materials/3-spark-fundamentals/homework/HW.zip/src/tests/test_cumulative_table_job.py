import pytest
from pyspark.sql import SparkSession
from ..jobs.cumulative_table_job import transform_cumulative_table
from chispa import assert_df_equality
from pyspark.sql.types import StructType, StructField, StringType, LongType, DoubleType, ArrayType

@pytest.fixture(scope="session")
def spark_session():
    spark = SparkSession.builder \
        .appName("test") \
        .getOrCreate()
    yield spark
    spark.stop()

def test_transform_cumulative_table(spark_session):
    input_data = [
        ("actor1", 1, "A", "Film1", 4.5, 2020),
        ("actor1", 1, "A", "Film2", 3.5, 2021),
        ("actor2", 2, "B", "Film3", 4.0, 2021),
        ("actor2", 2, "B", "Film4", 5.0, 2022)
    ]
    input_schema = ["actor", "actorid", "quality_class", "film", "rating", "year"]
    input_df = spark_session.createDataFrame(input_data, input_schema)

    expected_data = [
        ("actor1", 1, 2021, ["Film1", "Film2"], 4.0),
        ("actor2", 2, 2022, ["Film3", "Film4"], 4.5)
    ]
    expected_schema = [
        StructField("actor", StringType(), True),
        StructField("actorid", LongType(), True),
        StructField("current_year", LongType(), True),
        StructField("films", ArrayType(StringType(), False), False),  # Adjusted to match the actual schema
        StructField("avg_recent_rating", DoubleType(), True)
    ]
    expected_df = spark_session.createDataFrame(expected_data, StructType(expected_schema))

    result_df = transform_cumulative_table(spark_session, input_df)
    assert_df_equality(result_df, expected_df, ignore_column_order=True, ignore_nullable=False)
