import pytest
from pyspark.sql import SparkSession
from ..jobs.actors_history_scd_job import transform_actors_history_scd
from chispa import assert_df_equality
from pyspark.sql.types import StructType, StructField, StringType, LongType, BooleanType

@pytest.fixture(scope="session")
def spark_session():
    spark = SparkSession.builder \
        .appName("test") \
        .getOrCreate()
    yield spark
    spark.stop()

def test_transform_actors_history_scd(spark_session):
    input_data = [
        ("actor1", 1, "A", True, 2020),
        ("actor1", 1, "A", False, 2021),
        ("actor1", 1, "A", True, 2022),
        ("actor2", 2, "B", True, 2021)
    ]
    input_schema = ["actor", "actorid", "quality_class", "is_active", "current_year"]
    input_df = spark_session.createDataFrame(input_data, input_schema)

    expected_data = [
        ("actor1", 1, 2020, 2021, "A", True, False, 0),
        ("actor1", 1, 2021, 2022, "A", False, False, 1),
        ("actor1", 1, 2022, None, "A", True, True, 2),
        ("actor2", 2, 2021, None, "B", True, True, 0)
    ]
    expected_schema = [
        StructField("actor", StringType(), True),
        StructField("actorid", LongType(), True),
        StructField("start_date", LongType(), True),
        StructField("end_date", LongType(), True),
        StructField("quality_class", StringType(), True),
        StructField("is_active", BooleanType(), True),
        StructField("current_flag", BooleanType(), False),  # Adjusted to match the actual schema
        StructField("change_streak", LongType(), True)
    ]
    expected_df = spark_session.createDataFrame(expected_data, StructType(expected_schema))

    result_df = transform_actors_history_scd(spark_session, input_df)
    assert_df_equality(result_df, expected_df, ignore_column_order=True, ignore_nullable=False)
